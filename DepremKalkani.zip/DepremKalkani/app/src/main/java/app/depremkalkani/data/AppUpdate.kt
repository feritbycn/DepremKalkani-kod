package app.depremkalkani.data

import android.app.Activity
import android.content.Context
import com.google.android.play.core.appupdate.AppUpdateInfo
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.appupdate.AppUpdateOptions
import com.google.android.play.core.install.InstallStateUpdatedListener
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Google Play uygulama içi güncelleme (esnek mod): indirme arka planda sürer, uygulama kullanılmaya devam eder.
 * Yalnızca Play'den kurulan sürümlerde çalışır; elle kurulan APK'da güncelleme "yok" görünür.
 */
object AppUpdate {
    enum class Phase { NONE, AVAILABLE, DOWNLOADING, DOWNLOADED }

    val phase = MutableStateFlow(Phase.NONE)
    val progress = MutableStateFlow(0)

    private var mgr: AppUpdateManager? = null
    private var info: AppUpdateInfo? = null
    private var listener: InstallStateUpdatedListener? = null

    fun check(ctx: Context) {
        runCatching {
            val m = mgr ?: AppUpdateManagerFactory.create(ctx.applicationContext).also { mgr = it }
            if (listener == null) {
                val l = InstallStateUpdatedListener { st ->
                    when (st.installStatus()) {
                        InstallStatus.DOWNLOADING -> {
                            val total = st.totalBytesToDownload()
                            progress.value = if (total > 0) (st.bytesDownloaded() * 100 / total).toInt().coerceIn(0, 100) else 0
                            phase.value = Phase.DOWNLOADING
                        }
                        InstallStatus.DOWNLOADED -> phase.value = Phase.DOWNLOADED
                        InstallStatus.FAILED, InstallStatus.CANCELED -> phase.value = if (info != null) Phase.AVAILABLE else Phase.NONE
                        else -> {}
                    }
                }
                m.registerListener(l); listener = l
            }
            m.appUpdateInfo.addOnSuccessListener { i ->
                info = i
                when {
                    i.installStatus() == InstallStatus.DOWNLOADED -> phase.value = Phase.DOWNLOADED
                    i.installStatus() == InstallStatus.DOWNLOADING -> phase.value = Phase.DOWNLOADING
                    i.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE && i.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE) -> phase.value = Phase.AVAILABLE
                    phase.value == Phase.AVAILABLE -> phase.value = Phase.NONE
                }
            }
        }
    }

    /** "Güncelle"ye basınca: Play'in onay penceresi çıkar, onaylanırsa indirme arka planda başlar. */
    fun start(activity: Activity) {
        val i = info ?: return
        runCatching {
            mgr?.startUpdateFlow(i, activity, AppUpdateOptions.newBuilder(AppUpdateType.FLEXIBLE).build())
                ?.addOnSuccessListener { code ->
                    if (code == Activity.RESULT_OK) { progress.value = 0; phase.value = Phase.DOWNLOADING }
                }
        }
    }

    /** İndirme bitince kurar ve uygulamayı yeniden başlatır. */
    fun install() { runCatching { mgr?.completeUpdate() } }
}
