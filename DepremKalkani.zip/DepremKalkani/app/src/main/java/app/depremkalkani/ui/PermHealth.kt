package app.depremkalkani.ui

import android.Manifest
import android.content.Context
import android.net.ConnectivityManager
import android.os.Build
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import app.depremkalkani.R
import app.depremkalkani.data.Notifs
import app.depremkalkani.dk

enum class PK { NOTIF, LOC, BATT, MONITOR, FSI, NEARBY, BGDATA, MIC }

class PItem(val kind: PK, val emoji: String, val title: String, val why: String, val required: Boolean, val ok: Boolean, val action: String)

/** Uygulamanın düzgün çalışması için gereken izin/ayarların durumu. */
object PermHealth {
    fun items(ctx: Context): List<PItem> {
        val prefs = ctx.dk.prefs
        val nm = ctx.getSystemService(android.app.NotificationManager::class.java)
        val pm = ctx.getSystemService(PowerManager::class.java)
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val notifOk = NotificationManagerCompat.from(ctx).areNotificationsEnabled()
        val locOk = Perms.has(ctx, arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION)) || Perms.has(ctx, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION))
        val battOk = runCatching { pm.isIgnoringBatteryOptimizations(ctx.packageName) }.getOrDefault(true)
        val fsiOk = Build.VERSION.SDK_INT < 34 || runCatching { nm.canUseFullScreenIntent() }.getOrDefault(true)
        val bgOk = runCatching { cm.restrictBackgroundStatus != ConnectivityManager.RESTRICT_BACKGROUND_STATUS_ENABLED }.getOrDefault(true)
        return listOf(
            PItem(PK.NOTIF, "🔔", "Bildirimler", "Deprem, sismik dalga ve yakınlarından gelen uyarıların sana ulaşması için.", true, notifOk, "İzin ver"),
            PItem(PK.LOC, "📍", "Konum", "Depremin sana uzaklığını hesaplamak ve bölgene göre uyarmak için. Konumun sunucuya kaydedilmez.", true, locOk, "İzin ver"),
            PItem(PK.BATT, "🔋", "Pil kısıtlaması yok", "Telefon pil tasarrufuna girince uygulamanın kapanmaması ve uyarıların gecikmemesi için.", true, battOk, "Kısıtlamayı kaldır"),
            PItem(PK.MONITOR, "📡", "Canlı takip", "Uygulama kapalıyken bile depremleri arka planda takip eder.", true, prefs.monitorOn, "Aç"),
            PItem(PK.FSI, "📲", "Kilit ekranında tam ekran uyarı", "Ekran kilitliyken sismik dalga uyarısı ve geri sayım hemen açılsın.", false, fsiOk, "İzin ver"),
            PItem(PK.NEARBY, "🤝", "Yakındaki cihazlar", "İnternet yokken çevrendeki kullanıcılara mesaj ve SOS iletmek için (Bluetooth).", false, Perms.hasNearby(ctx), "İzin ver"),
            PItem(PK.BGDATA, "📶", "Arka planda veri", "Veri tasarrufu açıksa arka plandaki takip ve bildirimler engellenebilir.", false, bgOk, "Ayarı aç"),
            PItem(PK.MIC, "🎙️", "Mikrofon", "Yalnızca sesli mesaj kaydederken kullanılır, isteğe bağlıdır.", false, Perms.has(ctx, arrayOf(Manifest.permission.RECORD_AUDIO)), "İzin ver"),
        )
    }

    fun missingRequired(ctx: Context) = items(ctx).filter { it.required && !it.ok }

    private const val ID = 7300

    /** Her ayar için sade, davetkâr hatırlatma metni (başlık, gövde). */
    private fun reminder(k: PK): Pair<String, String>? = when (k) {
        PK.NEARBY -> "Yakındaki cihazlar izni kapalı" to "İnternet yokken çevrendeki kişilerle iletişim kurabilmen için izin vermen gerekiyor. Dokun ve aç."
        PK.LOC -> "Konum izni kapalı" to "Depremin sana ne kadar yakın olduğunu söyleyebilmem ve bölgene göre uyarabilmem için konum iznine ihtiyacım var."
        PK.BATT -> "Pil kısıtlaması uyarıları geciktirebilir" to "Telefon pil tasarrufuna girince deprem uyarıların geç gelebilir. Kısıtlamayı kaldırmak için dokun."
        PK.MONITOR -> "Canlı takip kapalı" to "Uygulama kapalıyken depremleri takip edemiyorum. Açmak için dokun."
        PK.FSI -> "Kilit ekranı uyarısı kapalı" to "Sismik dalga uyarısının ekran kilitliyken hemen açılması için izin ver."
        PK.BGDATA -> "Veri tasarrufu bildirimleri engelliyor" to "Arka planda veri kısıtlı olduğu için deprem bildirimlerin gecikebilir. Ayarı açmak için dokun."
        PK.NOTIF, PK.MIC -> null
    }

    /**
     * Eksik bir izin/ayar varsa arada bir (önemli eksik varsa günde bir, yoksa 3 günde bir) sessiz bir hatırlatma gönderir.
     * Eksikler sırayla döner, aynı şeyle üst üste rahatsız etmez. Her şey tamamsa bildirim kaldırılır.
     */
    fun checkAndNotify(ctx: Context) {
        val prefs = ctx.dk.prefs
        val all = items(ctx)
        val miss = all.filter { !it.ok && reminder(it.kind) != null }
        val nm = NotificationManagerCompat.from(ctx)
        if (miss.isEmpty()) { runCatching { nm.cancel(ID) }; return }
        if (!Notifs.canPost(ctx)) return
        val gap = if (miss.any { it.required }) 86_400_000L else 3 * 86_400_000L
        if (System.currentTimeMillis() - prefs.sp.getLong("ph_last", 0L) < gap) return
        val order = miss.sortedByDescending { it.required }
        val lastKind = prefs.sp.getString("ph_kind", "")
        val idx = order.indexOfFirst { it.kind.name == lastKind }
        val pick = order[(idx + 1) % order.size]
        val (title, body) = reminder(pick.kind) ?: return
        prefs.sp.edit().putLong("ph_last", System.currentTimeMillis()).putString("ph_kind", pick.kind.name).apply()
        val n = NotificationCompat.Builder(ctx, Notifs.CH_HEALTH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_LOW).setAutoCancel(true)
            .setContentIntent(Notifs.openDestIntent(ctx, "perms")).build()
        runCatching { nm.notify(ID, n) }
    }
}
