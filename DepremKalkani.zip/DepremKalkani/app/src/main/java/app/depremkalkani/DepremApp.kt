package app.depremkalkani

import android.app.Application
import android.content.Context
import app.depremkalkani.data.Notifs
import app.depremkalkani.data.Prefs
import app.depremkalkani.data.QuakeRepository
import app.depremkalkani.mesh.Mesh
import app.depremkalkani.billing.BillingManager
import org.osmdroid.config.Configuration

class DepremApp : Application() {
    val prefs by lazy { Prefs(this) }
    val repo by lazy { QuakeRepository(this) }
    val billing by lazy { BillingManager(this, prefs) }

    override fun onCreate() {
        super.onCreate()
        // Çökme kaydı: bir sonraki açılışta ekranda gösterilir (bazı telefonlarda açılışta kapanma teşhisi için)
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching { java.io.File(filesDir, "last_crash.txt").writeText(
                "Sürüm: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}, Android ${android.os.Build.VERSION.SDK_INT}\n" +
                    android.util.Log.getStackTraceString(e).take(6000)) }
            prev?.uncaughtException(t, e)
        }
        runCatching { Notifs.createChannels(this) }
        runCatching { prefs.migrateRegionDefault() }
        runCatching { Mesh.init(this, prefs) }
        runCatching { app.depremkalkani.data.Circles.init(this, prefs) }
        runCatching {
            Configuration.getInstance().apply {
                userAgentValue = packageName
                osmdroidBasePath = cacheDir
                osmdroidTileCache = cacheDir.resolve("tiles")
            }
        }
    }
}

