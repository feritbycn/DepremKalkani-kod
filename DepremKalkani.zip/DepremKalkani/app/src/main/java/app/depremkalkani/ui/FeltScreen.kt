package app.depremkalkani.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.depremkalkani.data.CrowdFelt
import app.depremkalkani.data.Geo
import app.depremkalkani.service.LocationHelper
import kotlinx.coroutines.launch

/** Bildirime basınca açılan ekran: bölgedeki bildirim sayısı + Hissettim / Hissetmedim. */
@Composable
fun FeltScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val stat by CrowdFelt.stat.collectAsState()
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<String?>(null) }
    var loaded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { LocationHelper.refresh(ctx); CrowdFelt.refresh(ctx); loaded = true }

    fun vote(felt: Boolean) {
        scope.launch {
            busy = true
            val ok = CrowdFelt.report(ctx, felt)
            result = when {
                !Geo.known -> "Konum alınamadı. Konum iznini verip tekrar dene."
                ok -> if (felt) "Hissettiğin bildirildi ✓" else "\"Hissetmedim\" kaydedildi ✓"
                else -> "İnternete ulaşılamadı, oy gönderilemedi. Tekrar dene."
            }
            toast(ctx, result!!)
            CrowdFelt.refresh(ctx)
            busy = false
        }
    }

    PullToRefreshBox(isRefreshing = busy, onRefresh = { busy = true; scope.launch { kotlinx.coroutines.delay(900); busy = false }; scope.launch { CrowdFelt.refresh(ctx) } }, modifier = Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card2(brush = DK.Hero) {
            Text("Kullanıcılar deprem hissedildiğini bildiriyor", color = Color.White, style = MaterialTheme.typography.titleLarge)
            val s = stat
            Text(
                when {
                    !loaded -> "Yükleniyor…"
                    !Geo.known -> "Konumun bilinmiyor; bölge hesaplanamadı."
                    s == null -> "Veriye ulaşılamadı (internet?)."
                    s.count == 0 -> "Son 15 dakikada ${s.region} için \"hissettim\" bildirimi yok."
                    else -> CrowdFelt.sentence(s.region, s.count) + "."
                },
                color = Color.White.copy(alpha = 0.92f), modifier = Modifier.padding(top = 6.dp),
            )
        }
        Text("Az önce sarsıntı hissettin mi?", style = MaterialTheme.typography.titleMedium)
        BigButton("Hissettim", { vote(true) }, enabled = !busy, color = DK.Danger)
        BigButton("Hissetmedim", { vote(false) }, enabled = !busy, outlined = true)
        result?.let { Text(it, color = DK.Teal, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold) }
        OutlinedButton({ scope.launch { busy = true; CrowdFelt.refresh(ctx); busy = false } }, enabled = !busy) { Text("Sayıyı yenile") }
        Text("Oylar yaklaşık konumunla (~10 km) ve rastgele cihaz kimliğinle, herkese açık ntfy aktarma sunucusuna yazılır; ad veya telefon numarası gönderilmez. " +
            "Doğrulama yapılmadığı için sayı kesin bilgi değildir; resmî bilgi için AFAD/Kandilli listesine bak. " +
            "Ayarlar'dan bildirimi kapatabilir veya eşiği değiştirebilirsin.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    DelayedLoader(!loaded, Modifier.align(androidx.compose.ui.Alignment.Center), "Veriler alınıyor…")
    }
}
