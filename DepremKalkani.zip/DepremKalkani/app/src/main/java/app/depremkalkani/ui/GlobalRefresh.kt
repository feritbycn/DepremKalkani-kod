package app.depremkalkani.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import app.depremkalkani.data.Circles
import app.depremkalkani.data.CrowdFelt
import app.depremkalkani.data.Sources
import app.depremkalkani.dk
import kotlinx.coroutines.launch

object RefreshClock {
    @Volatile var last = 0L
    private val busy = java.util.concurrent.atomic.AtomicBoolean(false)

    suspend fun run(ctx: android.content.Context) {
        runCatching { ctx.dk.repo.refresh(ctx.dk.prefs.sources.ifEmpty { setOf(Sources.AFAD) }) }
        runCatching { Circles.syncNow() }
        runCatching { CrowdFelt.refresh(ctx) }
        last = System.currentTimeMillis()
    }

    /** Sayfaya girişte sessiz yenileme: son yenilemeden 30 sn geçtiyse. */
    suspend fun maybe(ctx: android.content.Context) {
        if (System.currentTimeMillis() - last < 30_000L) return
        if (!busy.compareAndSet(false, true)) return
        try { run(ctx) } finally { busy.set(false) }
    }
}

/** Sayfayı aşağı çekince depremleri, Yakınlarım'ı ve "hissettim" verisini yeniler. */
@Composable
fun GlobalRefresh(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    PullToRefreshBox(
        isRefreshing = busy,
        onRefresh = {
            busy = true
            scope.launch { kotlinx.coroutines.delay(900); busy = false }
            scope.launch { RefreshClock.run(ctx) }
        },
        modifier = Modifier.fillMaxSize(),
    ) { content() }
}
