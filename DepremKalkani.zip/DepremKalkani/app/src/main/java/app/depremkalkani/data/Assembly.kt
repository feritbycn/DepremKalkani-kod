package app.depremkalkani.data

import android.content.Context
import okhttp3.FormBody
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class AssemblyPoint(val name: String, val lat: Double, val lon: Double)

/**
 * Toplanma alanları: OpenStreetMap'te "emergency=assembly_point" etiketli yerler (Overpass API).
 * Son sonuç telefona kaydedilir; internet yokken de görünür.
 * Resmî sorgu için AFAD "Acil Toplanma Alanı Sorgulama" e-Devlet hizmeti de uygulamadan açılabilir.
 */
object Assembly {
    const val AFAD_EDEVLET = "https://www.turkiye.gov.tr/afet-ve-acil-durum-yonetimi-acil-toplanma-alani-sorgulama"

    fun load(ctx: Context): List<AssemblyPoint> = runCatching {
        val a = JSONArray(File(ctx.filesDir, "assembly.json").readText())
        (0 until a.length()).map { val o = a.getJSONObject(it); AssemblyPoint(o.getString("n"), o.getDouble("la"), o.getDouble("lo")) }
    }.getOrDefault(emptyList())

    fun fetch(ctx: Context, lat: Double, lon: Double, radiusM: Int = 5000): List<AssemblyPoint> {
        val q = """[out:json][timeout:25];(node["emergency"="assembly_point"](around:$radiusM,$lat,$lon);
            way["emergency"="assembly_point"](around:$radiusM,$lat,$lon););out center 120;"""
        val req = Request.Builder().url("https://overpass-api.de/api/interpreter")
            .post(FormBody.Builder().add("data", q).build()).header("User-Agent", Mark.UA).build()
        val body = Sources.client.newCall(req).execute().use { it.body!!.string() }
        val els = JSONObject(body).getJSONArray("elements")
        val out = ArrayList<AssemblyPoint>()
        for (i in 0 until els.length()) {
            val e = els.getJSONObject(i)
            val tags = e.optJSONObject("tags")
            val name = tags?.optString("name").orEmpty().ifBlank { "Toplanma alanı" }
            val la = if (e.has("lat")) e.getDouble("lat") else e.optJSONObject("center")?.optDouble("lat") ?: continue
            val lo = if (e.has("lon")) e.getDouble("lon") else e.optJSONObject("center")?.optDouble("lon") ?: continue
            out += AssemblyPoint(name, la, lo)
        }
        val arr = JSONArray(); out.forEach { arr.put(JSONObject().put("n", it.name).put("la", it.lat).put("lo", it.lon)) }
        File(ctx.filesDir, "assembly.json").writeText(arr.toString())
        return out
    }
}
