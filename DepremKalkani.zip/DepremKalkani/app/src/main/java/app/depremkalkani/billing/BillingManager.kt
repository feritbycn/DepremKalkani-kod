package app.depremkalkani.billing

import android.app.Activity
import android.content.Context
import app.depremkalkani.BuildConfig
import app.depremkalkani.data.Prefs
import com.android.billingclient.api.*
import kotlinx.coroutines.flow.MutableStateFlow

enum class ProPlan { MONTHLY, YEARLY, LIFETIME }

/**
 * "Pro" = reklamsız + ek özellikler. Üç seçenek:
 *  - Aylık ve yıllık abonelik (Play Console: abonelik PRO_SUB_ID, temel planlar PRO_PLAN_MONTHLY / PRO_PLAN_YEARLY)
 *  - Tek seferlik ömür boyu (ürün PRO_PRODUCT_ID)
 * Bunlardan herhangi biri geçerliyse Pro açıktır.
 */
class BillingManager(private val ctx: Context, private val prefs: Prefs) {
    val isPro = MutableStateFlow(prefs.isPro && Guard.environmentClean(ctx))
    val price = MutableStateFlow<String?>(null)          // ömür boyu
    val priceMonthly = MutableStateFlow<String?>(null)
    val priceYearly = MutableStateFlow<String?>(null)
    val message = MutableStateFlow<String?>(null)
    private var lifetime: ProductDetails? = null
    private var sub: ProductDetails? = null

    private val client: BillingClient = BillingClient.newBuilder(ctx.applicationContext)
        .setListener { result, purchases ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) purchases.forEach { handle(it) }
            else if (result.responseCode != BillingClient.BillingResponseCode.USER_CANCELED)
                message.value = "Satın alma tamamlanamadı (${result.responseCode})."
        }
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .build()

    fun connect() {
        if (client.isReady) return
        client.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(r: BillingResult) {
                if (r.responseCode == BillingClient.BillingResponseCode.OK) { queryDetails(); restore() }
            }
            override fun onBillingServiceDisconnected() {}
        })
    }

    private fun offer(d: ProductDetails?, plan: String) =
        d?.subscriptionOfferDetails?.filter { it.basePlanId == plan }?.let { l -> l.firstOrNull { it.offerId == null } ?: l.firstOrNull() }

    private fun priceOf(o: ProductDetails.SubscriptionOfferDetails?) =
        o?.pricingPhases?.pricingPhaseList?.lastOrNull()?.formattedPrice

    private fun queryDetails() {
        fun p(id: String, type: String) = QueryProductDetailsParams.Product.newBuilder().setProductId(id).setProductType(type).build()
        client.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(listOf(p(BuildConfig.PRO_PRODUCT_ID, BillingClient.ProductType.INAPP))).build()) { _, res ->
            lifetime = res.productDetailsList.firstOrNull()
            price.value = lifetime?.oneTimePurchaseOfferDetails?.formattedPrice
        }
        client.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(listOf(p(BuildConfig.PRO_SUB_ID, BillingClient.ProductType.SUBS))).build()) { _, res ->
            sub = res.productDetailsList.firstOrNull()
            priceMonthly.value = priceOf(offer(sub, BuildConfig.PRO_PLAN_MONTHLY))
            priceYearly.value = priceOf(offer(sub, BuildConfig.PRO_PLAN_YEARLY))
        }
    }

    private fun isProPurchase(p: Purchase) = p.purchaseState == Purchase.PurchaseState.PURCHASED &&
        (p.products.contains(BuildConfig.PRO_PRODUCT_ID) || p.products.contains(BuildConfig.PRO_SUB_ID))

    fun restore() {
        if (!Guard.environmentClean(ctx)) {
            prefs.revokePro(); isPro.value = false
            message.value = "Bu kurulum doğrulanamadı (değiştirilmiş uygulama veya sahte satın alma aracı). Pro devre dışı. Uygulamayı Google Play'den yükle."
            return
        }
        // Hem tek seferlik hem abonelik sorgulanır; ikisi de başarılı yanıt verip hiçbiri geçerli değilse Pro kapanır.
        val lock = Any()
        var done = 0; var allOk = true; var any = false
        fun finish(ok: Boolean, valid: List<Purchase>) = synchronized(lock) {
            done++; if (!ok) allOk = false
            if (valid.isNotEmpty()) { any = true; valid.forEach { handle(it) } }
            if (done == 2 && allOk && !any) { prefs.revokePro(); isPro.value = false }   // Play "satın alım yok" diyorsa Pro kapanır (iade/iptal/sahte)
            // yanıt başarısızsa (çevrimdışı) mevcut imzalı kayıt korunur
        }
        for (type in listOf(BillingClient.ProductType.INAPP, BillingClient.ProductType.SUBS)) {
            client.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(type).build()) { r, list ->
                val ok = r.responseCode == BillingClient.BillingResponseCode.OK
                finish(ok, if (ok) list.filter { isProPurchase(it) && Guard.purchaseSignatureOk(it.originalJson, it.signature) } else emptyList())
            }
        }
    }

    fun buy(activity: Activity, plan: ProPlan) {
        val pd = ProductDetailsParams(plan)
        val params = pd ?: run { message.value = "Ürün bilgisi alınamadı. Play Console'da ürünün/planın tanımlı ve etkin olduğundan emin ol."; connect(); return }
        client.launchBillingFlow(activity, BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(params)).build())
    }

    private fun ProductDetailsParams(plan: ProPlan): BillingFlowParams.ProductDetailsParams? {
        val b = BillingFlowParams.ProductDetailsParams.newBuilder()
        return when (plan) {
            ProPlan.LIFETIME -> lifetime?.let { b.setProductDetails(it).build() }
            ProPlan.MONTHLY, ProPlan.YEARLY -> {
                val d = sub ?: return null
                val o = offer(d, if (plan == ProPlan.MONTHLY) BuildConfig.PRO_PLAN_MONTHLY else BuildConfig.PRO_PLAN_YEARLY) ?: return null
                b.setProductDetails(d).setOfferToken(o.offerToken).build()
            }
        }
    }

    private fun handle(p: Purchase) {
        if (!isProPurchase(p)) return
        if (!Guard.environmentClean(ctx) || !Guard.purchaseSignatureOk(p.originalJson, p.signature)) { message.value = "Satın alma doğrulanamadı."; return }
        if (!p.isAcknowledged) {
            client.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.purchaseToken).build()) {}
        }
        prefs.grantPro(p.purchaseToken); isPro.value = true; message.value = "Pro etkinleştirildi, teşekkürler!"
    }
}
