package app.depremkalkani.ui

import android.content.Context
import android.graphics.Color as AColor
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.OvalShape
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.depremkalkani.dk
import app.depremkalkani.data.*
import app.depremkalkani.service.LocationHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon

private fun dot(ctx: Context, color: Int, sizeDp: Int): ShapeDrawable {
    val px = (sizeDp * ctx.resources.displayMetrics.density).toInt()
    return ShapeDrawable(OvalShape()).apply {
        setIntrinsicHeight(px); setIntrinsicWidth(px); paint.color = color
        paint.alpha = 220
    }
}

@Composable
fun MapScreen(focus: Quake?, onOpen: (Quake) -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.dk
    val prefs = app.prefs
    val scope = rememberCoroutineScope()
    val quakes by app.repo.quakes.collectAsState()
    var minMag by remember { mutableFloatStateOf(maxOf(2.5f, prefs.listMinMag)) }
    var showAssembly by remember { mutableStateOf(false) }
    var assembly by remember { mutableStateOf(Assembly.load(ctx)) }
    var status by remember { mutableStateOf<String?>(null) }
    var assemblyLoading by remember { mutableStateOf(false) }
    val view = remember { MapView(ctx).apply {
        setTileSource(TileSourceFactory.MAPNIK); setMultiTouchControls(true)
        isTilesScaledToDpi = true   // telefon ekranında karolar/yazılar daha okunaklı
        controller.setZoom(6.0); controller.setCenter(GeoPoint(39.0, 35.0))
    } }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) view.onResume() else if (e == Lifecycle.Event.ON_PAUSE) view.onPause()
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs); view.onPause(); view.onDetach() }
    }

    LaunchedEffect(focus) {
        if (focus != null) {
            val d = Geo.distanceFromMe(focus)
            val offshore = Regex("ridge|ocean|sea|trench|rise|basin|fracture|rift|pacific|atlantic|indian|plateau|gulf|bay|off ", RegexOption.IGNORE_CASE)
                .containsMatchIn(focus.place)
            val turkish = focus.source == Sources.AFAD || focus.source == Sources.KANDILLI
            val zoom = when { turkish -> 9.0; offshore -> 5.0; else -> 7.0 }   // denizde/okyanusta geniş, karada yakın
            view.controller.setCenter(GeoPoint(focus.lat, focus.lon))
            if (Geo.known && d != null && d <= 900.0) {
                // sen yakınsan deprem ve konumun aynı karede görünsün
                val box = org.osmdroid.util.BoundingBox.fromGeoPoints(listOf(GeoPoint(focus.lat, focus.lon), GeoPoint(Geo.lat!!, Geo.lon!!)))
                view.post { runCatching { view.zoomToBoundingBox(box.increaseByScale(1.8f), false) } }
            } else view.controller.setZoom(zoom)
        }
        else if (Geo.known) { view.controller.setZoom(7.0); view.controller.setCenter(GeoPoint(Geo.lat!!, Geo.lon!!)) }
    }

    fun redraw() {
        view.overlays.clear()
        if (Geo.known) {
            view.overlays += Marker(view).apply {
                position = GeoPoint(Geo.lat!!, Geo.lon!!); title = "Konumum"
                icon = dot(ctx, AColor.parseColor("#2979FF"), 16); setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            }
        }
        val shown = quakes.filter { it.mag >= minMag }.take(400).reversed()
        for (q in shown) {
            view.overlays += Marker(view).apply {
                position = GeoPoint(q.lat, q.lon)
                title = "M%.1f  %s".format(java.util.Locale.US, q.mag, q.place)
                snippet = Notifs.ago(q.time) + " • " + q.depthKm.toInt() + " km • " + Sources.label(q.source)
                val sz = (10 + q.mag * 3.2).toInt().coerceIn(12, 40)
                icon = dot(ctx, DK.magColor(q.mag).toArgb(), sz)
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                setOnMarkerClickListener { m, _ -> if (m.isInfoWindowShown) { onOpen(q); true } else { m.showInfoWindow(); true } }
            }
        }
        if (focus != null) {
            val c = DK.magColor(focus.mag).toArgb()
            view.overlays += Marker(view).apply {   // dış halka
                position = GeoPoint(focus.lat, focus.lon); setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                icon = ShapeDrawable(OvalShape()).apply {
                    val px = (46 * ctx.resources.displayMetrics.density).toInt(); setIntrinsicWidth(px); setIntrinsicHeight(px)
                    paint.color = c; paint.style = android.graphics.Paint.Style.STROKE; paint.strokeWidth = 7f; paint.alpha = 200
                }
                setOnMarkerClickListener { _, _ -> true }
            }
            view.overlays += Marker(view).apply {   // merkez nokta
                position = GeoPoint(focus.lat, focus.lon); setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                icon = dot(ctx, c, 22)
                setOnMarkerClickListener { _, _ -> true }
            }
        }
        if (showAssembly) for (a in assembly) {
            view.overlays += Marker(view).apply {
                position = GeoPoint(a.lat, a.lon); title = a.name; snippet = "Toplanma alanı"
                icon = dot(ctx, AColor.parseColor("#22C55E"), 18); setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            }
        }
        view.invalidate()
    }
    LaunchedEffect(quakes, minMag, showAssembly, assembly) { redraw() }

    Box(Modifier.fillMaxSize()) {
        AndroidView({ view }, Modifier.fillMaxSize())
        DelayedLoader(assemblyLoading, Modifier.align(Alignment.Center), "Toplanma alanları aranıyor…")
        if (focus == null) Column(Modifier.align(Alignment.TopStart).padding(12.dp).statusBarsPadding(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(2.5f, 3f, 4f, 5f).forEach { m ->
                    FilterChip(selected = minMag == m, onClick = { minMag = m },
                        label = { Text("M${if (m % 1f == 0f) m.toInt().toString() else m.toString()}+") },
                        colors = FilterChipDefaults.filterChipColors(containerColor = MaterialTheme.colorScheme.surface))
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = showAssembly, onClick = {
                    showAssembly = !showAssembly
                    if (showAssembly) scope.launch {
                        LocationHelper.refresh(ctx)
                        if (Geo.known) {
                            status = "Toplanma alanları aranıyor…"; assemblyLoading = true
                            runCatching { withContext(Dispatchers.IO) { Assembly.fetch(ctx, Geo.lat!!, Geo.lon!!) } }
                                .onSuccess { assemblyLoading = false; assembly = it; status = if (it.isEmpty()) "Yakında kayıtlı toplanma alanı bulunamadı. AFAD sorgusunu dene." else null }
                                .onFailure { assemblyLoading = false; status = if (assembly.isEmpty()) "İnternet yok; kayıtlı toplanma alanı da yok." else "Çevrimdışı: kayıtlı alanlar gösteriliyor." }
                        } else status = "Konum bilinmiyor."
                    }
                }, label = { Text("Toplanma alanları") },
                    colors = FilterChipDefaults.filterChipColors(containerColor = MaterialTheme.colorScheme.surface))
                AssistChip(onClick = {
                    scope.launch {
                        LocationHelper.refresh(ctx)
                        if (Geo.known) { view.controller.setZoom(11.0); view.controller.animateTo(GeoPoint(Geo.lat!!, Geo.lon!!)) }
                    }
                }, label = { Text("Konumum") }, colors = AssistChipDefaults.assistChipColors(containerColor = MaterialTheme.colorScheme.surface))
            }
            status?.let {
                Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surface) {
                    Text(it, Modifier.padding(10.dp), style = MaterialTheme.typography.bodyMedium)
                }
            }
            if (showAssembly) TextButton({ Share.url(ctx, Assembly.AFAD_EDEVLET) }) { Text("AFAD resmî sorgusu (e-Devlet)") }
        }
        focus?.let { q -> FocusCard(q, Modifier.align(Alignment.BottomCenter).padding(12.dp)) { onOpen(q) } }
    }
}


/** "Haritada göster" ile açılan haritanın altındaki deprem bilgi kartı. */
@Composable
private fun FocusCard(q: Quake, modifier: Modifier, onDetail: () -> Unit) {
    val c = DK.magColor(q.mag)
    val tr = java.util.Locale("tr")
    val date = java.text.SimpleDateFormat("d MMMM yyyy", tr).format(java.util.Date(q.time))
    val hour = java.text.SimpleDateFormat("HH:mm", tr).format(java.util.Date(q.time))
    val d = Geo.distanceFromMe(q)
    Surface(onClick = onDetail, modifier = modifier.fillMaxWidth(), shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface, shadowElevation = 8.dp) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(58.dp).clip(androidx.compose.foundation.shape.CircleShape).background(c), contentAlignment = Alignment.Center) {
                    Text(String.format(java.util.Locale.US, "%.1f", q.mag), color = androidx.compose.ui.graphics.Color.White,
                        fontSize = 22.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(q.place, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                    Text(Notifs.ago(q.time) + (d?.let { " • sana ${fmtDist(it)}" } ?: ""), fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            HorizontalDivider()
            Row(Modifier.fillMaxWidth()) {
                InfoCell("Tarih", date, Modifier.weight(1f)); InfoCell("Kaynak", Sources.label(q.source), Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth()) {
                InfoCell("Saat", hour, Modifier.weight(1f)); InfoCell("Derinlik", "${"%.1f".format(java.util.Locale.US, q.depthKm)} km", Modifier.weight(1f))
            }
            Text("Ayrıntı için karta dokun", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun InfoCell(label: String, value: String, modifier: Modifier) {
    Column(modifier) {
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontSize = 15.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
    }
}
