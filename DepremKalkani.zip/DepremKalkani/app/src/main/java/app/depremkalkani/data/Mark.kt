package app.depremkalkani.data

/** Telif işareti: uygulamanın kaynağını gösteren gizli iz. Kopyada da aynen görünür; silinmemeli. */
object Mark {
    const val ID = "frtbycn"
    const val UA = "DepremKalkani/1.0 (frtbycn)"
    /** Paket adına bağlı sabit imza; kopyada paket adı değişse de ID aynı kalır. */
    fun sig(pkg: String): String = java.security.MessageDigest.getInstance("SHA-256").digest("$ID|$pkg|DK".toByteArray())
        .take(8).joinToString("") { "%02x".format(it) }
}
