package app.depremkalkani.data

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.*

data class Quake(
    val id: String,
    val source: String,        // AFAD, KANDILLI, EMSC, USGS, TARIHI
    val time: Long,            // epoch ms (UTC)
    val lat: Double,
    val lon: Double,
    val depthKm: Double,
    val mag: Double,
    val place: String,
    val province: String = "",
    val url: String? = null,
) {
    fun toJson() = JSONObject().apply {
        put("id", id); put("s", source); put("t", time); put("la", lat); put("lo", lon)
        put("d", depthKm); put("m", mag); put("p", place); put("pr", province); put("u", url ?: "")
    }

    companion object {
        fun fromJson(o: JSONObject) = Quake(
            o.getString("id"), o.getString("s"), o.getLong("t"), o.getDouble("la"), o.getDouble("lo"),
            o.getDouble("d"), o.getDouble("m"), o.getString("p"), o.optString("pr"),
            o.optString("u").ifBlank { null },
        )
        fun listToJson(l: List<Quake>) = JSONArray().also { a -> l.forEach { a.put(it.toJson()) } }
        fun listFromJson(a: JSONArray) = (0 until a.length()).mapNotNull {
            runCatching { fromJson(a.getJSONObject(it)) }.getOrNull()
        }
    }
}

object Geo {
    @Volatile var lat: Double? = null
    @Volatile var lon: Double? = null
    val known get() = lat != null && lon != null

    fun distanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        return 2 * r * asin(min(1.0, sqrt(a)))
    }

    fun bearingDeg(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val p1 = Math.toRadians(lat1); val p2 = Math.toRadians(lat2)
        val dl = Math.toRadians(lon2 - lon1)
        val y = sin(dl) * cos(p2)
        val x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
        return (Math.toDegrees(atan2(y, x)) + 360) % 360
    }

    fun compass(deg: Double): String {
        val n = arrayOf("Kuzey", "Kuzeydoğu", "Doğu", "Güneydoğu", "Güney", "Güneybatı", "Batı", "Kuzeybatı")
        return n[((deg + 22.5) / 45).toInt() % 8]
    }

    fun distanceFromMe(q: Quake): Double? =
        if (known) distanceKm(lat!!, lon!!, q.lat, q.lon) else null

    fun distanceFromMe(lat2: Double, lon2: Double): Double? =
        if (known) distanceKm(lat!!, lon!!, lat2, lon2) else null
}

fun String.asciiUpper(): String {
    val map = mapOf('ı' to 'I', 'İ' to 'I', 'ş' to 'S', 'Ş' to 'S', 'ğ' to 'G', 'Ğ' to 'G',
        'ü' to 'U', 'Ü' to 'U', 'ö' to 'O', 'Ö' to 'O', 'ç' to 'C', 'Ç' to 'C')
    val sb = StringBuilder()
    for (c in this) sb.append(map[c] ?: c.uppercaseChar())
    return sb.toString()
}

val TURKEY_PROVINCES = listOf(
    "Adana", "Adıyaman", "Afyonkarahisar", "Ağrı", "Aksaray", "Amasya", "Ankara", "Antalya", "Ardahan", "Artvin",
    "Aydın", "Balıkesir", "Bartın", "Batman", "Bayburt", "Bilecik", "Bingöl", "Bitlis", "Bolu", "Burdur", "Bursa",
    "Çanakkale", "Çankırı", "Çorum", "Denizli", "Diyarbakır", "Düzce", "Edirne", "Elazığ", "Erzincan", "Erzurum",
    "Eskişehir", "Gaziantep", "Giresun", "Gümüşhane", "Hakkari", "Hatay", "Iğdır", "Isparta", "İstanbul", "İzmir",
    "Kahramanmaraş", "Karabük", "Karaman", "Kars", "Kastamonu", "Kayseri", "Kilis", "Kırıkkale", "Kırklareli",
    "Kırşehir", "Kocaeli", "Konya", "Kütahya", "Malatya", "Manisa", "Mardin", "Mersin", "Muğla", "Muş", "Nevşehir",
    "Niğde", "Ordu", "Osmaniye", "Rize", "Sakarya", "Samsun", "Şanlıurfa", "Siirt", "Sinop", "Sivas", "Şırnak",
    "Tekirdağ", "Tokat", "Trabzon", "Tunceli", "Uşak", "Van", "Yalova", "Yozgat", "Zonguldak",
)

/** "Sismik dalga testi" için üretilen yapay deprem (listeye girmez). */
object TestQuake {
    @Volatile var q: Quake? = null
    fun make(distKm: Int): Quake {
        if (!Geo.known) { Geo.lat = 41.0082; Geo.lon = 28.9784 }  // konum yoksa test için İstanbul varsay
        val t = Quake("test-" + System.currentTimeMillis(), "TEST", System.currentTimeMillis(),
            Geo.lat!! + distKm / 111.0, Geo.lon!!, 8.0, 6.2, "TEST • Deneme depremi (gerçek değil)")
        q = t
        return t
    }
}
