package app.depremkalkani.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.depremkalkani.dk
import app.depremkalkani.data.Geo
import app.depremkalkani.mesh.Mesh
import app.depremkalkani.mesh.MsgType
import app.depremkalkani.service.LocationHelper
import app.depremkalkani.service.RescueService
import app.depremkalkani.service.RescueState
import kotlinx.coroutines.launch

@Composable
fun EmergencyScreen(onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = ctx.dk.prefs
    val scope = rememberCoroutineScope()
    val active by RescueState.active.collectAsState()
    val connected by Mesh.peers.collectAsState()
    var whistle by remember { mutableStateOf(prefs.whistleMaxVolume) }
    var sosPattern by remember { mutableStateOf(prefs.whistleSos) }
    var flash by remember { mutableStateOf(prefs.rescueFlash) }
    var beacon by remember { mutableStateOf(prefs.rescueBeacon) }
    var info by remember { mutableStateOf<String?>(null) }
    var report by remember { mutableStateOf<String?>(null) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        // izin sonucu ne olursa olsun düdük/flaş çalışır; konum/Bluetooth olmazsa yalnızca SOS yayını sınırlı olur
        RescueService.start(ctx, whistle = true, flash = flash, beacon = beacon)
    }

    fun startRescue() {
        val need = (Perms.location + Perms.notification + (if (beacon) Perms.nearby else emptyArray<String>())).distinct().toTypedArray()
        if (!Perms.has(ctx, need)) permLauncher.launch(need)
        else RescueService.start(ctx, whistle = true, flash = flash, beacon = beacon)
    }

    fun sendStatus(type: MsgType, text: String) {
        scope.launch {
            LocationHelper.refresh(ctx)
            Mesh.send(type, text)
            val ct = when (type) { MsgType.SAFE -> app.depremkalkani.data.CType.SAFE; MsgType.SOS -> app.depremkalkani.data.CType.SOS; else -> app.depremkalkani.data.CType.HELP }
            app.depremkalkani.data.Circles.sendAll(ct, text)
            val phones = prefs.contacts.map { it.phone }
            val nearby = Mesh.connectedCount
            val circ = app.depremkalkani.data.Circles.members.value.size
            report = buildString {
                append("\"$text\" gönderildi.\n\n")
                if (Mesh.running.value) append("• Yakındaki cihazlar: $nearby bağlı cihaza iletildi" + (if (nearby == 0) " (şu an yakında cihaz yok; biri bağlanınca otomatik iletilecek)" else "") + "\n")
                else append("• Yakın cihaz ağı KAPALI. 'Yakınımdakiler' sekmesinden aç.\n")
                append(if (circ > 0) "• Yakınlarım: $circ kişiye şifreli gönderildi (internet yoksa sıraya alındı).\n" else "• Yakınlarım: kimse eklenmemiş.\n")
                append(if (phones.isNotEmpty()) "• SMS: mesaj ekranı açılacak, GÖNDER'e basmayı unutma." else "• SMS: acil kişi eklenmemiş (Ayarlar).")
                if (!Geo.known) append("\n\nUyarı: konum alınamadığı için konumun mesaja eklenemedi.")
            }
            toast(ctx, "Gönderildi ✓")
            if (phones.isNotEmpty()) Share.sms(ctx, phones, Share.myStatusText(prefs, text))
        }
    }

    var ask by remember { mutableStateOf<Pair<MsgType, String>?>(null) }
    ask?.let { a -> StatusConfirmDialog(a.first, onOk = { ask = null; sendStatus(a.first, a.second) }, onCancel = { ask = null }) }

    report?.let { r ->
        AlertDialog(
            onDismissRequest = { report = null },
            confirmButton = { TextButton({ report = null }) { Text("Tamam") } },
            title = { Text("Gönderim durumu") },
            text = { Text(r) },
        )
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Acil Durum", style = MaterialTheme.typography.headlineLarge)

        // ---- SOS ana düğme
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(if (active) DK.SosBrush else DK.Hero).padding(20.dp),
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text(if (active) "ACİL MODU AÇIK" else "ENKAZ ALTINDAYIM", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                Text(
                    if (active) "Düdük çalıyor${if (flash) ", flaş SOS veriyor" else ""}${if (beacon) ", yakındakilere SOS yayınlanıyor" else ""}."
                    else "Düdüğü son sesle çalar, flaşla SOS verir ve yakındaki telefonlara konumunla yardım çağrısı yayınlar. Ekran kapansa da sürer.",
                    color = Color.White.copy(alpha = 0.9f), textAlign = TextAlign.Center, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp),
                )
                Button(
                    onClick = { if (active) RescueService.stop(ctx) else startRescue() },
                    modifier = Modifier.fillMaxWidth().height(64.dp), shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = if (active) Color(0xFF222222) else DK.Danger),
                ) { Text(if (active) "DURDUR" else "BAŞLAT", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold) }
            }
        }

        Card2 {
            Text("Acil mod ayarları", style = MaterialTheme.typography.titleMedium)
            SwitchRow("Düdük sesini son sese çıkar", "Alarm ve medya ses seviyesini maksimuma alır, bitince eski haline döner.", whistle) { whistle = it; prefs.whistleMaxVolume = it }
            SwitchRow("3'lü kısa düdük düzeni (SOS)", "Uluslararası yardım işareti: 3 kısa düdük, bekleme. Kapalıysa sürekli öter.", sosPattern) { sosPattern = it; prefs.whistleSos = it }
            SwitchRow("Flaş ile SOS ışığı", checked = flash) { flash = it; prefs.rescueFlash = it }
            SwitchRow("Yakındaki cihazlara SOS yayını", "İnternet olmadan da çalışır. 20 sn'de bir konumunla tekrarlanır.", beacon) { beacon = it; prefs.rescueBeacon = it }
            if (active) Text("Bağlı yakın cihaz: ${connected.values.count { it.connected }}", color = DK.Teal, fontWeight = FontWeight.SemiBold)
        }

        Text("Durumunu bildir", style = MaterialTheme.typography.titleMedium)
        Text("Yakındaki cihazlara gider. Acil kişi eklediysen SMS ekranı da açılır (hücresel şebeke varsa internetsiz çalışır).",
            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BigButton("Güvendeyim", { ask = MsgType.SAFE to "Güvendeyim" }, Modifier.weight(1f), color = DK.Teal)
            BigButton("Yaralıyım", { ask = MsgType.INJURED to "Yaralıyım, yardım lazım" }, Modifier.weight(1f), color = DK.Accent2)
        }
        BigButton("Su / yiyecek / ilaç lazım", { ask = MsgType.NEED to "Su, yiyecek ve ilaç lazım" }, outlined = true, color = DK.Accent2)
        BigButton("Enkaz altındayım — yardım edin", { ask = MsgType.SOS to "Enkaz altındayım, yardım edin!" }, color = DK.Danger)
        info?.let { Text(it, color = DK.Teal, fontSize = 13.sp) }

        Card2 {
            Text("Konumum", style = MaterialTheme.typography.titleMedium)
            var loc by remember { mutableStateOf(if (Geo.known) "%.5f, %.5f".format(java.util.Locale.US, Geo.lat, Geo.lon) else "Bilinmiyor") }
            Text(loc, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                OutlinedButton({ scope.launch {
                    LocationHelper.refresh(ctx)
                    loc = if (Geo.known) "%.5f, %.5f".format(java.util.Locale.US, Geo.lat, Geo.lon) else "Konum alınamadı (izin / GPS)"
                } }, Modifier.weight(1f)) { Text("Yenile") }
                OutlinedButton({ if (Geo.known) Share.text(ctx, Share.myStatusText(prefs, "Konumum")) }, Modifier.weight(1f)) { Text("Paylaş") }
            }
        }

        Card2 {
            Text("Acil numaralar", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                BigButton("112 Acil", { Share.dial(ctx, "112") }, Modifier.weight(1f), color = DK.Danger)
                BigButton("122 AFAD", { Share.dial(ctx, "122") }, Modifier.weight(1f), outlined = true)
            }
            Text("Arama tuşları numarayı çevirici ekrana yazar; sen arama düğmesine basarsın.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
        }
        TextButton(onSettings) { Text("Acil kişileri ve tıbbi notu düzenle") }
    }
}
