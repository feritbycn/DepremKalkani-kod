package app.depremkalkani.data

import java.util.Locale

/** Ad alanına telefon numarası yazılmasını engeller (rakamla ya da yazıyla). */
object NickGuard {
    private val words = listOf(
        "sifir", "bir", "iki", "uc", "dort", "bes", "alti", "yedi", "sekiz", "dokuz",
        "on", "yirmi", "otuz", "kirk", "elli", "altmis", "yetmis", "seksen", "doksan", "yuz",
        "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "oh"
    ).sortedByDescending { it.length }
    private val wordRx = Regex(words.joinToString("|"))

    private fun fold(s: String): String {
        val t = s.lowercase(Locale("tr", "TR"))
            .replace('ı', 'i').replace('ş', 's').replace('ğ', 'g').replace('ü', 'u').replace('ö', 'o').replace('ç', 'c')
            .replace('â', 'a').replace('î', 'i').replace('û', 'u')
        return t
    }

    fun bad(name: String): Boolean {
        if (name.isBlank()) return false
        val digits = name.count { Character.isDigit(it) }
        if (digits >= 7) return true
        val squashed = fold(name).filter { it.isLetter() }
        val ms = wordRx.findAll(squashed).toList()
        val covered = ms.sumOf { it.value.length }
        val numWords = if (squashed.isNotEmpty() && covered * 10 >= squashed.length * 7) ms.size else 0
        // yazıyla en az 5 sayı kelimesi, ya da rakam + kelime toplamı 7 ve üstü
        if (numWords >= 5) return true
        val mixed = ms.size + digits
        return digits > 0 && ms.isNotEmpty() && mixed >= 7
    }

    fun clean(name: String): String = if (bad(name)) "" else name
}
