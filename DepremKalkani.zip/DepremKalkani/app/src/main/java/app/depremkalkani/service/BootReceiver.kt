package app.depremkalkani.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import app.depremkalkani.dk

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (ctx.dk.prefs.monitorOn || app.depremkalkani.data.Circles.members.value.isNotEmpty()) runCatching { MonitorService.start(ctx) }
    }
}
