package app.depremkalkani.service

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import app.depremkalkani.data.Geo
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.tasks.await

object LocationHelper {
    fun hasPermission(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Konumu günceller ve Geo nesnesine yazar. Başarısız olursa sessizce eski değeri korur. */
    @SuppressLint("MissingPermission")
    suspend fun refresh(ctx: Context): Boolean {
        if (!hasPermission(ctx)) return false
        return runCatching {
            val c = LocationServices.getFusedLocationProviderClient(ctx)
            val loc = c.lastLocation.await()
                ?: c.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, CancellationTokenSource().token).await()
            if (loc != null) { Geo.lat = loc.latitude; Geo.lon = loc.longitude; true } else false
        }.getOrDefault(false)
    }
}
