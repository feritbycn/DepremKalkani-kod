package app.depremkalkani.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.depremkalkani.R
import app.depremkalkani.dk
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/** Merkezden yayılan sismik dalga halkaları + akan sismograf çizgisi. */
@Composable
fun SeismicLoader(modifier: Modifier = Modifier, color: Color = DK.Accent, rings: Boolean = true) {
    val t = rememberInfiniteTransition(label = "seismic")
    val phase by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "ring")
    val flow by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1600, easing = LinearEasing)), label = "flow")
    Canvas(modifier) {
        val cx = size.width / 2; val cy = size.height / 2
        val maxR = minOf(size.width, size.height) / 2 * (if (rings) 1f else 0f)
        if (rings) for (i in 0..2) {
            val p = (phase + i / 3f) % 1f
            drawCircle(color.copy(alpha = (1f - p) * 0.55f), radius = maxR * p, center = Offset(cx, cy), style = Stroke(width = 3.dp.toPx() * (1f - p) + 1f))
        }
        // akan sismograf çizgisi: ortada büyük, kenarlara doğru sönen genlik
        val path = Path()
        val n = 90
        for (i in 0..n) {
            val x = size.width * i / n
            val u = i / n.toFloat()
            val env = (1f - abs(u - 0.5f) * 2f).coerceAtLeast(0f)
            val y = cy + sin((u * 7f - flow * 2f) * 2 * PI.toFloat()) * size.height * 0.28f * env * env +
                sin((u * 19f - flow * 5f) * 2 * PI.toFloat()) * size.height * 0.07f * env
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, color, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Açılış ekranı: logo + yayılan dalgalar. En az ~1,3 sn görünür; veri gelince (en fazla ~3,5 sn) solarak kapanır. */
@Composable
fun AppSplash(skip: Boolean) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val quakes by ctx.dk.repo.quakes.collectAsState()
    var show by remember { mutableStateOf(!skip) }
    LaunchedEffect(Unit) {
        if (skip) return@LaunchedEffect
        kotlinx.coroutines.delay(1300)
        var waited = 0L
        while (quakes.isEmpty() && waited < 2200) { kotlinx.coroutines.delay(100); waited += 100 }
        show = false
    }
    AnimatedVisibility(show, exit = fadeOut(tween(450))) {
        Box(Modifier.fillMaxSize().background(Color(0xFF0A0F1F)), contentAlignment = Alignment.Center) {
            SeismicLoader(Modifier.size(300.dp), color = DK.Accent)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size(120.dp))
            }
            Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 72.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Deprem Kalkanı", color = Color.White, fontSize = 22.sp, style = MaterialTheme.typography.titleLarge)
                Text("Veriler alınıyor…", color = DK.Muted, fontSize = 13.sp)
            }
        }
    }
}


/** Bekleme yarım saniyeyi aşarsa ortada dalga animasyonu gösterir; hızlı biten işlerde hiç görünmez. */
@Composable
fun DelayedLoader(active: Boolean, modifier: Modifier = Modifier, label: String? = null, delayMs: Long = 500) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(active) {
        if (active) { kotlinx.coroutines.delay(delayMs); visible = true } else visible = false
    }
    AnimatedVisibility(visible && active, modifier, enter = fadeIn(tween(200)), exit = fadeOut(tween(250))) {
        androidx.compose.material3.Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f), shadowElevation = 8.dp) {
            Column(Modifier.padding(horizontal = 24.dp, vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                SeismicLoader(Modifier.size(150.dp, 110.dp), color = DK.Accent)
                if (label != null) Text(label, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
