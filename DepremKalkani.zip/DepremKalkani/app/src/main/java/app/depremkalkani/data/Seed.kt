package app.depremkalkani.data

import java.text.SimpleDateFormat
import java.util.*

/** Uygulamayla birlikte gelen, internet olmasa da görünen önemli depremler (tarihî kayıtlar). */
object Seed {
    private fun t(s: String): Long = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        .apply { timeZone = TimeZone.getTimeZone("UTC") }.parse(s)!!.time

    val notable: List<Quake> = listOf(
        Quake("H-2023-1", "TARIHI", t("2023-02-06 01:17"), 37.17, 37.03, 8.6, 7.8, "Pazarcık (Kahramanmaraş) — Kahramanmaraş depremi", "Kahramanmaraş"),
        Quake("H-2023-2", "TARIHI", t("2023-02-06 10:24"), 38.02, 37.20, 7.0, 7.5, "Elbistan (Kahramanmaraş)", "Kahramanmaraş"),
        Quake("H-2020-2", "TARIHI", t("2020-10-30 11:51"), 37.90, 26.78, 10.0, 6.9, "Sisam / Seferihisar açıkları (İzmir)", "İzmir"),
        Quake("H-2020-1", "TARIHI", t("2020-01-24 17:55"), 38.43, 39.06, 8.0, 6.8, "Sivrice (Elazığ)", "Elazığ"),
        Quake("H-2011-1", "TARIHI", t("2011-10-23 10:41"), 38.72, 43.36, 17.0, 7.1, "Tabanlı / Erciş (Van)", "Van"),
        Quake("H-2003-1", "TARIHI", t("2003-05-01 00:27"), 38.97, 40.46, 10.0, 6.4, "Bingöl", "Bingöl"),
        Quake("H-1999-2", "TARIHI", t("1999-11-12 16:57"), 40.77, 31.15, 10.0, 7.2, "Düzce", "Düzce"),
        Quake("H-1999-1", "TARIHI", t("1999-08-17 00:01"), 40.75, 29.86, 17.0, 7.6, "Gölcük (Kocaeli) — Marmara depremi", "Kocaeli"),
        Quake("H-1998-1", "TARIHI", t("1998-06-27 13:55"), 36.88, 35.30, 23.0, 6.3, "Ceyhan (Adana)", "Adana"),
        Quake("H-1939-1", "TARIHI", t("1939-12-26 23:57"), 39.80, 39.51, 20.0, 7.8, "Erzincan depremi", "Erzincan"),
    )

    /** Önemli depremlerin bilinen etkileri. Rakamlar resmî açıklamalara dayalı yaklaşık değerlerdir. */
    class Info(val fault: String, val deaths: String, val injured: String, val damage: String, val note: String = "")

    val info: Map<String, Info> = mapOf(
        "H-2023-1" to Info("Doğu Anadolu Fayı (Pazarcık segmenti)", "Türkiye'de 50 binden fazla (resmî yaklaşık 50.800); Suriye'de binlerce", "Türkiye'de 100 binden fazla",
            "11 ilde yüz binlerce yapı yıkıldı, ağır hasar aldı veya yıkılması gerekti", "Aynı gün Elbistan depremiyle (M7.5) birlikte yaşandı. Türkiye'nin yakın tarihteki en ölümcül depremi."),
        "H-2023-2" to Info("Çardak Fayı", "Pazarcık depremiyle birlikte sayılır", "Pazarcık depremiyle birlikte sayılır",
            "Pazarcık depreminden yaklaşık 9 saat sonra; mevcut hasarı artırdı", "Aynı gün iki büyük depremin yaşandığı nadir bir olay."),
        "H-2020-2" to Info("Kuzey Sisam Fayı (Ege Denizi)", "Türkiye'de 117, Yunanistan'da 2", "Türkiye'de 1.000'den fazla",
            "İzmir'de onlarca bina yıkıldı veya ağır hasar aldı; Seferihisar'da küçük bir tsunami oluştu", "Büyüklük kurumlara göre 6,6–7,0 arasında açıklandı."),
        "H-2020-1" to Info("Doğu Anadolu Fayı (Pütürge segmenti)", "41", "1.600'den fazla",
            "Elazığ ve Malatya'da yüzlerce bina yıkıldı veya ağır hasar aldı"),
        "H-2011-1" to Info("Van bindirme fayı", "Yaklaşık 600", "4.000'den fazla",
            "Van ve Erciş'te binlerce bina yıkıldı veya ağır hasar aldı", "Yaklaşık iki hafta sonra Edremit'te (M5,6) ikinci bir deprem daha oldu."),
        "H-2003-1" to Info("Karlıova Üçlü Birleşimi yakını", "Yaklaşık 177", "Yaklaşık 500", "Bingöl'de binlerce bina hasar gördü; çok sayıda okul yıkıldı"),
        "H-1999-2" to Info("Kuzey Anadolu Fayı (Düzce segmenti)", "Yaklaşık 845", "Yaklaşık 5.000", "Düzce ve Bolu'da binlerce bina yıkıldı veya ağır hasar aldı",
            "Marmara depreminden yaklaşık üç ay sonra olduğu için zaten hasarlı bölgeyi vurdu."),
        "H-1999-1" to Info("Kuzey Anadolu Fayı (İzmit segmenti)", "Yaklaşık 17.000 (resmî 17.480)", "Yaklaşık 44.000", "Kocaeli, Sakarya, İstanbul, Yalova ve Bolu'da on binlerce bina yıkıldı veya ağır hasar aldı",
            "Marmara Bölgesi'nin sanayi merkezini vurdu; Türkiye'de yapı denetimi ve deprem sigortası (DASK) tartışmalarının dönüm noktasıdır."),
        "H-1998-1" to Info("Misis / Karataş fay sistemi", "Yaklaşık 145", "Yaklaşık 1.500", "Adana ve Ceyhan'da binlerce bina hasar gördü"),
        "H-1939-1" to Info("Kuzey Anadolu Fayı", "Yaklaşık 33.000", "Binlerce", "Erzincan kenti büyük ölçüde yıkıldı",
            "Cumhuriyet döneminin en ölümcül depremi; Kuzey Anadolu Fayı'ndaki ardışık kırılmaların başlangıcı sayılır."),
    )
}
