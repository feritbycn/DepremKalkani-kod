package app.depremkalkani.ui

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import app.depremkalkani.data.CloudBackup
import app.depremkalkani.dk
import app.depremkalkani.service.MonitorService
import com.google.android.gms.auth.api.identity.Identity
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun fmtBackupTime(ts: Long): String =
    if (ts <= 0L) "henüz yok" else SimpleDateFormat("d MMM yyyy HH:mm", Locale("tr")).format(Date(ts))

private fun isoToMillis(s: String): Long = runCatching {
    val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
    f.parse(s.take(19))!!.time
}.getOrDefault(0L)

/**
 * Drive "uygulama verisi" iznini ister. İzin alınınca: bulutta yedek varsa geri yükleme sorulur, yoksa ilk yedek alınır.
 * Dönen işlev çağrılınca akış başlar; her durumda sonunda [onFinished] mesajla çağrılır.
 */
@Composable
fun rememberDriveSetup(recreateAfterRestore: Boolean, onFinished: (String) -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val prefs = ctx.dk.prefs
    val scope = rememberCoroutineScope()
    var found by remember { mutableStateOf<Pair<String, CloudBackup.Remote>?>(null) }
    val finished by rememberUpdatedState(onFinished)

    suspend fun withToken(token: String) {
        prefs.driveGranted = true
        val r = CloudBackup.find(token)
        if (r == null) {
            val ok = CloudBackup.backupNow(ctx, token, prefs)
            finished(if (ok) "İlk yedek Google hesabına alındı." else "Yedek alınamadı. Drive API'nin açık olduğundan emin ol, sonra tekrar dene.")
        } else found = token to r
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        scope.launch {
            val t = runCatching { Identity.getAuthorizationClient(ctx).getAuthorizationResultFromIntent(res.data).accessToken }.getOrNull()
            if (t == null) finished("Yedekleme izni verilmedi.") else withToken(t)
        }
    }

    found?.let { (token, remote) ->
        val whenTxt = fmtBackupTime(isoToMillis(remote.modified).let { if (it == 0L) 0L else it })
        AlertDialog(
            onDismissRequest = { found = null; finished("Geri yükleme yapılmadı.") },
            title = { Text("Yedek bulundu") },
            text = { Text("Bu Google hesabına ait bir yedek var (son yedek: $whenTxt). Yakınların ve ayarların geri yüklensin mi? Yedekte konum, mesaj geçmişi ve Pro kaydı yoktur.") },
            confirmButton = {
                TextButton({
                    found = null
                    scope.launch {
                        val ok = CloudBackup.restore(ctx, token, remote, prefs)
                        if (ok) {
                            runCatching { MonitorService.start(ctx) }
                            finished("Yedek geri yüklendi.")
                            if (recreateAfterRestore) (ctx as? Activity)?.recreate()
                        } else finished("Yedek geri yüklenemedi.")
                    }
                }) { Text("Geri yükle") }
            },
            dismissButton = {
                TextButton({ found = null; finished("Geri yükleme yapılmadı; sonraki otomatik yedek eskisinin üstüne yazar.") }) { Text("Yeni başla") }
            },
        )
    }

    return remember {
        {
            scope.launch {
                try {
                    val r = CloudBackup.authorize(ctx)
                    val pi = r.pendingIntent
                    if (r.hasResolution() && pi != null) launcher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                    else if (r.accessToken != null) withToken(r.accessToken!!)
                    else finished("Yedekleme izni alınamadı.")
                } catch (e: Exception) {
                    finished("Yedekleme kurulamadı: ${e.message ?: e.javaClass.simpleName}")
                }
            }
            Unit
        }
    }
}
