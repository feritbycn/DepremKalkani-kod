package app.depremkalkani.service

import android.app.Notification
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import app.depremkalkani.R
import app.depremkalkani.dk
import app.depremkalkani.data.*
import app.depremkalkani.sensor.SeismoEngine
import app.depremkalkani.ui.Perms
import kotlinx.coroutines.*
import java.util.Calendar

/**
 * Arka planda seçili kaynaklardan (AFAD, Kandilli, EMSC, USGS) veri çeker ve
 * kullanıcının bölge/büyüklük filtresine uyan YENİ depremler için bildirim gönderir.
 * Aracı sunucu gerekmez; bu yüzden telefonda kalıcı bildirimle (ön plan servisi) çalışır.
 */
class MonitorService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default + CoroutineExceptionHandler { _, e -> android.util.Log.w("DK", "coroutine", e) })
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf(); return START_NOT_STICKY
        }
        try {
            val n = buildNotification()
            if (Build.VERSION.SDK_INT >= 34)
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(1, n)
        } catch (e: Exception) {
            // Bazı telefonlar arka plandan ön plan servisine izin vermez; uygulama çökmesin
            android.util.Log.w("DK", "startForeground", e); stopSelf(); return START_NOT_STICKY
        }

        runCatching { app.depremkalkani.mesh.Mesh.autoStart(Perms.hasNearby(this)) }
        if (job?.isActive != true) {
            job = scope.launch { loop() }
            scope.launch { Circles.subscribeLoop() }
            // Güvenlik ağı: akış sessizce kopsa bile yakın mesajları en geç 20 sn içinde çekilir
            scope.launch { while (isActive) { delay(20_000); if (Circles.members.value.isNotEmpty()) runCatching { Circles.pollNow() } } }
            registerNetCallback()
            scope.launch { delay(90_000); while (isActive) { runCatching { app.depremkalkani.ui.PermHealth.checkAndNotify(this@MonitorService) }; delay(6 * 3600_000L) } }
            scope.launch {
                while (isActive) {
                    delay(45_000)
                    runCatching { CrowdFelt.check(this@MonitorService) }
                }
            }
        }
        if (dk.prefs.shakeDetect) runCatching { SeismoEngine.acquire(this, "svc") }
        return START_STICKY
    }

    private var netCb: android.net.ConnectivityManager.NetworkCallback? = null

    /** İnternet geri gelince (Wi-Fi/mobil veri değişimi, uyku çıkışı) bağlantıyı hemen tazele. */
    private fun registerNetCallback() {
        if (netCb != null) return
        runCatching {
            val cm = getSystemService(android.net.ConnectivityManager::class.java)
            val cb = object : android.net.ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: android.net.Network) {
                    if (Circles.members.value.isNotEmpty()) scope.launch { runCatching { Circles.reconnectNow() } }
                }
            }
            cm.registerDefaultNetworkCallback(cb); netCb = cb
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, Notifs.CH_MONITOR)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Deprem Kalkanı çalışıyor")
            .setContentText("Depremler canlı takip ediliyor")
            .setOngoing(true)
            .setContentIntent(Notifs.openAppIntent(this))
            .build()

    private suspend fun loop() {
        val prefs = dk.prefs
        val repo = dk.repo
        var first = prefs.seenIds.isEmpty()
        while (currentCoroutineContext().isActive) {
            if (!prefs.monitorOn) { delay(10_000); continue }
            runCatching {
                LocationHelper.refresh(this@MonitorService)
                app.depremkalkani.data.Circles.broadcastProvince()
                val list = repo.refresh(prefs.sources.ifEmpty { setOf(Sources.AFAD) })
                val seen = prefs.seenIds.toMutableSet()
                val now = System.currentTimeMillis()
                val fresh = list.filter { it.id !in seen && now - it.time < 45 * 60_000L }
                for (q in fresh.sortedBy { it.time }) {
                    seen += q.id
                    if (first) { rememberNotified(prefs, q); continue } // ilk çalıştırmada eski depremler için bildirim yağdırma
                    // kaynak/revizyon yüzünden kimliği değişen AYNI depremi ikinci kez bildirme
                    if (alreadyNotified(prefs, q)) continue
                    rememberNotified(prefs, q)
                    runCatching { app.depremkalkani.data.Circles.checkQuake(q) }
                    if (QuakeRepository.matches(q, prefs) && allowedAtThisHour(q, prefs)) Notifs.notifyQuake(this@MonitorService, q, prefs)
                }
                // eski kayıtları da "görüldü" say
                list.forEach { seen += it.id }
                // set sırasız olduğu için takeLast rastgele kayıt atıyordu; güncel listedekileri her zaman koru
                val cur = list.map { it.id }.toSet()
                prefs.seenIds = (seen - cur).take(1500).toSet() + cur
                first = false
            }
            delay(prefs.pollSeconds * 1000)
        }
    }

    /** Bildirilen depremlerin parmak izi: "zaman|enlem|boylam" (3 saat tutulur). */
    private fun rememberNotified(p: Prefs, q: Quake) {
        val now = System.currentTimeMillis()
        val keep = p.sp.getStringSet("notified_fp", emptySet()).orEmpty().filter {
            (it.substringBefore('|').toLongOrNull() ?: 0L) > now - 3 * 3600_000L
        }.toMutableSet()
        keep += "${q.time}|${q.lat}|${q.lon}"
        p.sp.edit().putStringSet("notified_fp", keep).apply()
    }

    /** Aynı olay: başlangıç zamanı ~3 dk ve merkez ~0,5° içinde (farklı kaynak ya da revize kayıt). */
    private fun alreadyNotified(p: Prefs, q: Quake): Boolean =
        p.sp.getStringSet("notified_fp", emptySet()).orEmpty().any {
            val a = it.split('|')
            a.size == 3 && kotlin.math.abs((a[0].toLongOrNull() ?: 0L) - q.time) < 180_000 &&
                kotlin.math.abs((a[1].toDoubleOrNull() ?: 999.0) - q.lat) < 0.5 &&
                kotlin.math.abs((a[2].toDoubleOrNull() ?: 999.0) - q.lon) < 0.5
        }

    private fun allowedAtThisHour(q: Quake, p: Prefs): Boolean {
        if (!p.nightMode) return true
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val night = h >= 23 || h < 7
        return !night || q.mag >= 5.0
    }

    override fun onDestroy() {
        runCatching { netCb?.let { getSystemService(android.net.ConnectivityManager::class.java).unregisterNetworkCallback(it) } }
        Circles.stop(); job?.cancel(); scope.cancel()
        SeismoEngine.release("svc")
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "stop"
        fun start(ctx: Context) {
            val i = Intent(ctx, MonitorService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, MonitorService::class.java)) }
    }
}
