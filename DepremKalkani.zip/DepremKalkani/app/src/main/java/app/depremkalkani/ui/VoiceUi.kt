package app.depremkalkani.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import app.depremkalkani.mesh.Mesh
import app.depremkalkani.mesh.MeshMsg
import app.depremkalkani.mesh.MsgType
import app.depremkalkani.mesh.Voice
import kotlinx.coroutines.delay

/** Sesli mesaj gönderme: kaydet → alıcıyı SEN seç (varsayılan hiçbir yere gitmez). */
@Composable
fun VoiceSendDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val peers by Mesh.peers.collectAsState()
    val msgs by Mesh.messages.collectAsState()
    val rec = remember { Voice.Recorder(ctx) }
    var phase by remember { mutableStateOf(0) }       // 0 hazır, 1 kayıt, 2 alıcı seç
    var secs by remember { mutableStateOf(0) }
    var err by remember { mutableStateOf<String?>(null) }
    var amps by remember { mutableStateOf(listOf<Int>()) }
    DisposableEffect(Unit) { onDispose { rec.release() } }

    fun finish() {
        if (phase != 1) return
        phase = if (rec.stop()) 2 else 0
        if (phase == 0) err = "Kayıt alınamadı."
    }
    fun begin() {
        err = null; secs = 0
        if (rec.start()) phase = 1 else err = "Mikrofon açılamadı."
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) begin() else err = "Mikrofon izni verilmedi."
    }
    LaunchedEffect(phase) {
        if (phase == 1) {
            amps = emptyList()
            var t = 0
            while (t < Voice.MAX_SECONDS * 1000) {
                delay(100); t += 100
                amps = (amps + rec.amp()).takeLast(40)
                secs = t / 1000
            }
            finish()
        }
    }
    val cMembers by app.depremkalkani.data.Circles.members.collectAsState()
    val connected = peers.values.filter { it.connected }
    val sosActive = remember(msgs) { Mesh.hasActiveSos() }

    AlertDialog(
        onDismissRequest = { rec.release(); onDismiss() },
        confirmButton = { TextButton({ rec.release(); onDismiss() }) { Text("Kapat") } },
        title = { Text("Sesli mesaj") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when (phase) {
                    0 -> {
                        Text("En çok ${Voice.MAX_SECONDS} sn kaydedersin. Ses yalnızca seçtiğin alıcıya gider, alıcıda 2 saat kalıp silinir.", fontSize = 13.sp)
                        Button({
                            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) begin()
                            else perm.launch(Manifest.permission.RECORD_AUDIO)
                        }, Modifier.fillMaxWidth()) { Text("Kaydı başlat") }
                    }
                    1 -> {
                        Text("Kaydediliyor… $secs / ${Voice.MAX_SECONDS} sn", fontSize = 15.sp)
                        val barColor = MaterialTheme.colorScheme.primary
                        Canvas(Modifier.fillMaxWidth().height(56.dp)) {
                            val n = 40
                            val step = size.width / n
                            val mid = size.height / 2
                            for (i in 0 until n) {
                                val idx = i - (n - amps.size)
                                val a = if (idx >= 0) amps[idx] else 0
                                val h = (a / 12000f).coerceIn(0.06f, 1f) * size.height / 2
                                drawLine(barColor, Offset(i * step + step / 2, mid - h), Offset(i * step + step / 2, mid + h), strokeWidth = step * 0.55f, cap = StrokeCap.Round)
                            }
                        }
                        if (secs >= 2 && amps.takeLast(10).all { it < 500 }) Text("Ses algılanmıyor. Mikrofona yaklaşıp konuş.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                        Button({ finish() }, Modifier.fillMaxWidth()) { Text("Bitir") }
                    }
                    else -> {
                        Text("$secs sn kaydedildi. Kime gönderilsin?", fontSize = 14.sp)
                        if (connected.isEmpty() && cMembers.none { !it.group }) Text("Şu an bağlı cihaz ya da yakının yok.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                        cMembers.filter { !it.group }.forEach { cm ->
                            OutlinedButton({
                                val e = app.depremkalkani.data.Circles.sendVoice(cm, rec.out, secs)
                                toast(ctx, e ?: "Ses ${cm.name} kişisine gönderiliyor ✓ (internet yoksa sıraya alınır)")
                                if (e == null) onDismiss()
                            }, Modifier.fillMaxWidth()) { Text("Yakınım: ${cm.name}") }
                        }
                        connected.forEach { p ->
                            OutlinedButton({
                                val ok = Mesh.sendVoice(rec.out, secs, p.devId)
                                toast(ctx, if (ok) "Ses gönderildi ✓" else "Gönderilemedi")
                                if (ok) onDismiss()
                            }, Modifier.fillMaxWidth()) { Text("Bağlı kişi: ${p.nick}") }
                        }
                        Button({
                            val ok = Mesh.sendVoice(rec.out, secs, null)
                            toast(ctx, if (ok) "Ses gönüllülere gönderildi ✓" else "Gönüllü bulunamadı")
                            if (ok) onDismiss()
                        }, Modifier.fillMaxWidth(), enabled = sosActive && connected.isNotEmpty()) { Text("Yakındaki gönüllüler") }
                        Text(if (sosActive) "Uyarı: bağlı olan ve gönüllü modunu açmış herkes bu sesi dinleyebilir."
                            else "Gönüllülere ses göndermek için önce SOS göndermiş olmalısın.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        TextButton({ phase = 0 }) { Text("Yeniden kaydet") }
                    }
                }
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
            }
        },
    )
}

/** Sesli mesaj balonu eki: dinle, yavaş dinle, kalan süre, "tekrar söyle". */
@Composable
fun VoiceControls(m: MeshMsg, mine: Boolean) {
    val ctx = LocalContext.current
    val player = remember { Voice.Player() }
    DisposableEffect(Unit) { onDispose { player.stop() } }
    var playing by remember { mutableStateOf(false) }
    var slow by remember { mutableStateOf(false) }
    var heardSent by remember(m.id) { mutableStateOf(false) }
    val left = Voice.minutesLeft(ctx, m.id)
    if (left == null) {
        Text("Süresi doldu, ses silindi.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Button({
            if (playing) { player.stop(); playing = false }
            else {
                if (!mine && !heardSent) {   // ilk dinlemede karşıya "dinlendi" bilgisi
                    heardSent = true
                    val ev = app.depremkalkani.data.Circles.events.value.firstOrNull { it.id == m.id }
                    val mem = ev?.let { e -> app.depremkalkani.data.Circles.members.value.firstOrNull { it.id == e.memberId } }
                    if (mem != null) app.depremkalkani.data.Circles.send(mem, app.depremkalkani.data.CType.READ, m.id) else Mesh.sendHeard(m.id)
                }
                playing = true; player.play(Voice.file(ctx, m.id), if (slow) 0.75f else 1f) { playing = false } }
        }) { Text(if (playing) "Durdur" else "Dinle") }
        FilterChip(slow, { slow = !slow }, label = { Text("0,75x yavaş") })
        if (!mine) TextButton({
            val ev = app.depremkalkani.data.Circles.events.value.firstOrNull { it.id == m.id }
            val mem = ev?.let { e -> app.depremkalkani.data.Circles.members.value.firstOrNull { it.id == e.memberId } }
            if (mem != null) app.depremkalkani.data.Circles.send(mem, app.depremkalkani.data.CType.TEXT, "Sesini anlayamadım, tekrar söyler misin?")
            else Mesh.send(MsgType.TEXT, "Sesini anlayamadım, tekrar söyler misin?", withLocation = false, to = m.from)
            toast(ctx, "İstek gönderildi")
        }) { Text("Tekrar söyle") }
    }
    Text("Ses $left dk sonra silinecek", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
}
