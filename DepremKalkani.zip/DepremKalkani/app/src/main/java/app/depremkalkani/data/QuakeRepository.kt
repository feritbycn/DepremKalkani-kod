package app.depremkalkani.data

import android.content.Context
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import java.io.File
import kotlin.math.abs

class QuakeRepository(private val ctx: Context) {
    private val file = File(ctx.filesDir, "quakes.json")
    private val _quakes = MutableStateFlow<List<Quake>>(emptyList())
    val quakes: StateFlow<List<Quake>> = _quakes
    val loading = MutableStateFlow(false)
    val lastUpdate = MutableStateFlow(0L)
    val error = MutableStateFlow<String?>(null)
    private val lock = Any()

    init {
        // Uygulama açılır açılmaz son kaydedilen veriler hazır olsun (internet olmasa da).
        runCatching {
            if (file.exists()) _quakes.value = Quake.listFromJson(JSONArray(file.readText()))
        }
    }

    /** Seçili kaynakları paralel çeker, birleştirir, tekilleştirir, önbelleğe yazar. */
    suspend fun refresh(sources: Set<String>): List<Quake> = withContext(Dispatchers.IO) {
        loading.value = true
        val errs = mutableListOf<String>()
        val fetched = coroutineScope {
            sources.map { s ->
                async {
                    runCatching { Sources.fetch(s) }.getOrElse { errs += "${Sources.label(s)}: ${it.message}"; emptyList() }
                }
            }.awaitAll().flatten()
        }
        val merged = synchronized(lock) {
            val cutoff = System.currentTimeMillis() - 7 * 86400_000L
            val all = (fetched + _quakes.value).filter { it.time >= cutoff }
            val res = dedupe(all).sortedByDescending { it.time }.take(2000)
            _quakes.value = res
            runCatching { file.writeText(Quake.listToJson(res).toString()) }
            res
        }
        error.value = if (fetched.isEmpty() && errs.isNotEmpty()) errs.first() else null
        if (fetched.isNotEmpty()) lastUpdate.value = System.currentTimeMillis()
        loading.value = false
        merged
    }

    companion object {
        private val rank = mapOf(Sources.AFAD to 0, Sources.KANDILLI to 1, Sources.EMSC to 2, Sources.GEOFON to 3, Sources.USGS to 4, Sources.GEONET to 5)

        /** Aynı depremi birden çok kaynak bildirir: 90 sn ve ~0,5° içindekileri tek kayda indirir. */
        fun dedupe(list: List<Quake>): List<Quake> {
            val sorted = list.distinctBy { it.id }.sortedWith(compareBy({ rank[it.source] ?: 9 }, { -it.time }))
            val kept = ArrayList<Quake>()
            for (q in sorted) {
                val dup = kept.any {
                    abs(it.time - q.time) < 90_000 && abs(it.lat - q.lat) < 0.5 && abs(it.lon - q.lon) < 0.5
                }
                if (!dup) kept += q
            }
            return kept
        }

        fun matches(q: Quake, p: Prefs, minMag: Float = p.notifMinMag): Boolean {
            if (p.bigWorld && p.region != RegionMode.WORLD && q.mag >= p.bigWorldMag) return true
            if (q.mag < minMag) return false
            return when (p.region) {
                RegionMode.WORLD -> true
                RegionMode.TURKEY -> inTurkeyArea(q)
                RegionMode.PROVINCES -> {
                    val sel = p.provinces.map { it.asciiUpper() }
                    sel.isNotEmpty() && sel.any { prov ->
                        q.province.asciiUpper().contains(prov) || q.place.asciiUpper().contains(prov)
                    }
                }
                RegionMode.RADIUS -> Geo.distanceFromMe(q)?.let { it <= p.radiusKm } ?: inTurkeyArea(q)
            }
        }

        /** Türkiye ve yakın çevresi (kabaca): 35-43°K, 25-45°D */
        fun inTurkeyArea(q: Quake) = q.lat in 34.5..43.0 && q.lon in 24.5..45.5
    }
}
