package app.depremkalkani.data

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import app.depremkalkani.MainActivity
import app.depremkalkani.R
import java.text.SimpleDateFormat
import java.util.*

object Notifs {
    const val CH_MONITOR = "monitor"
    const val CH_MESH = "mesh_sos"
    const val CH_SHAKE = "shake"
    const val CH_RESCUE = "rescue"
    const val CH_CIRCLE = "circle"
    const val CH_FELT = "felt"
    const val CH_HEALTH = "health"
    fun quakeChannel(s: AlertSound) = "quake_" + s.name.lowercase()
    fun chatChannel(p: Prefs) = "chat_" + p.chatSound.name.lowercase()

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val alarmAttr = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        nm.createNotificationChannel(NotificationChannel(CH_MONITOR, "Canlı takip", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Deprem verisini arka planda takip ederken görünen kalıcı bildirim"
            setShowBadge(false)
        })
        for (s in AlertSound.values()) {
            nm.createNotificationChannel(NotificationChannel(quakeChannel(s), "Deprem bildirimi • ${s.label}", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Seçtiğin bölge ve büyüklükteki depremler"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 600, 250, 600, 250, 900)
                val uri: Uri = if (s.raw == null) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                else Uri.parse("android.resource://${ctx.packageName}/" + rawId(ctx, s))
                setSound(uri, alarmAttr)
            })
        }
        val noteAttr = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        for (s in AlertSound.soft) {
            nm.createNotificationChannel(NotificationChannel("chat_" + s.name.lowercase(), "Mesajlar • ${s.label}", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Yakınlarım, Yakındakiler ve sohbet odası mesajları"
                enableVibration(true)
                val uri: Uri = if (s.raw == null) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                else Uri.parse("android.resource://${ctx.packageName}/" + rawId(ctx, s))
                setSound(uri, noteAttr)
            })
        }
        nm.createNotificationChannel(NotificationChannel(CH_MESH, "Yakındaki SOS / mesajlar", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "İnternetsiz yakın cihazlardan gelen yardım çağrıları ve mesajlar"
            enableVibration(true)
        })
        nm.createNotificationChannel(NotificationChannel(CH_CIRCLE, "Yakınlarım", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Yakınlarının \"Güvendeyim\" / \"Güvende misin?\" / yardım mesajları"
            enableVibration(true)
        })
        nm.createNotificationChannel(NotificationChannel(CH_HEALTH, "Kurulum hatırlatması", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Uyarıları etkileyen eksik izin ve ayarlar için nadir hatırlatma"
        })
        nm.createNotificationChannel(NotificationChannel(CH_FELT, "Deprem hissedildi bildirimleri", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Bölgende çok sayıda kullanıcı deprem hissettiğini bildirdiğinde"
            enableVibration(true)
        })
        nm.createNotificationChannel(NotificationChannel(CH_SHAKE, "Sarsıntı algılandı", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Telefonun algıladığı olası deprem sarsıntısı"
        })
        nm.createNotificationChannel(NotificationChannel(CH_RESCUE, "Acil durum modu", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Düdük, flaş ve SOS yayını çalışırken görünür"
        })
    }

    private fun rawId(ctx: Context, s: AlertSound): Int = ctx.resources.getIdentifier(s.raw ?: "", "raw", ctx.packageName)

    fun canPost(ctx: Context) = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun openAppIntent(ctx: Context, extra: String? = null, alert: Boolean = false): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (extra != null) i.putExtra("quake_id", extra)
        if (alert) i.putExtra("alert", true)
        return PendingIntent.getActivity(ctx, extra?.hashCode() ?: 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /** Bildirime dokununca belirli sayfayı aç: "circle" = Yakınlarım, "mesh" = Yakınımdakiler. */
    fun openDestIntent(ctx: Context, dest: String, wifiReq: String? = null): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("dest", dest)
        if (wifiReq != null) i.putExtra("wifireq", wifiReq)
        return PendingIntent.getActivity(ctx, if (wifiReq != null) 8000 + (wifiReq.hashCode() and 0xFFFF) else 7100 + dest.hashCode() % 100, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun openFeltIntent(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("felt", true)
        return PendingIntent.getActivity(ctx, 7001, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun notifyFelt(ctx: Context, region: String, count: Int) {
        if (!canPost(ctx)) return
        val body = CrowdFelt.sentence(region, count)
        val n = NotificationCompat.Builder(ctx, CH_FELT)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Kullanıcılar deprem hissedildiğini bildiriyor")
            .setContentText(body).setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_MAX).setAutoCancel(true)
            .setContentIntent(openFeltIntent(ctx)).build()
        runCatching { NotificationManagerCompat.from(ctx).notify(7001, n) }
    }

    fun notifyQuake(ctx: Context, q: Quake, p: Prefs) {
        if (!canPost(ctx)) return
        val d = Geo.distanceFromMe(q)
        val where = d?.let {
            val dir = Geo.compass(Geo.bearingDeg(Geo.lat!!, Geo.lon!!, q.lat, q.lon))
            "Sana ${it.toInt()} km • $dir yönünde"
        } ?: "Konumun bilinmiyor"
        // "Kumluca (Antalya) bölgesinde 3.5 büyüklüğünde deprem": "-da/-de" eki gerekmediği için her yer adında doğru okunur
        val title = "${q.place} bölgesinde ${"%.1f".format(Locale.US, q.mag)} büyüklüğünde deprem"
        val text = "$where • ${q.depthKm.toInt()} km derinlik • ${Sources.label(q.source)} • ${hhmm(q.time)}"
        val b = NotificationCompat.Builder(ctx, quakeChannel(p.sound))
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setColor(magColorInt(q.mag))
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(ctx, q.id, alert = (d != null && d <= WaveRule.radiusKm(q.mag, p.waveAlertKm))))
        if (q.mag >= 4.0 && app.depremkalkani.data.Circles.members.value.isNotEmpty())
            b.addAction(0, "Yakınlarıma: Güvendeyim", app.depremkalkani.data.Circles.safeActionIntent())
        if (!p.vibrate) b.setVibrate(longArrayOf(0))
        // Ekran kapalı / uygulama kapalıyken sismik dalga ekranını kendiliğinden aç (yakın ve taze depremler)
        val near = d != null && d <= WaveRule.radiusKm(q.mag, p.waveAlertKm)   // konum yoksa ya da deprem o mesafeden hissedilmeyecek kadar küçükse tam ekran uyarı açma
        if (near && System.currentTimeMillis() - q.time < 15 * 60_000L)
            b.setFullScreenIntent(openAppIntent(ctx, q.id, alert = true), true)
        runCatching { NotificationManagerCompat.from(ctx).notify(q.id.hashCode(), b.build()) }
        runCatching { Speaker.maybeSpeak(ctx, q, p, d) }
    }

    fun hhmm(t: Long): String = SimpleDateFormat("HH:mm", Locale("tr")).format(Date(t))

    fun magColorInt(m: Double): Int = when {
        m >= 6 -> 0xFFB5179E.toInt(); m >= 5 -> 0xFFE5383B.toInt(); m >= 4 -> 0xFFFF8A00.toInt()
        m >= 3 -> 0xFFFFC53D.toInt(); else -> 0xFF2DD4BF.toInt()
    }

    fun ago(t: Long): String {
        val s = (System.currentTimeMillis() - t) / 1000
        return when {
            s < 60 -> "şimdi"
            s < 3600 -> "${s / 60} dk önce"
            s < 86400 -> "${s / 3600} sa önce"
            s < 86400 * 30 -> "${s / 86400} gün önce"
            else -> SimpleDateFormat("d MMM yyyy", Locale("tr")).format(Date(t))
        }
    }
}

/** Sismik dalga (tam ekran) uyarısı yalnızca deprem o mesafeden hissedilebilecek büyüklükteyse açılır; kullanıcının mesafe ayarı üst sınırdır. */
object WaveRule {
    fun radiusKm(mag: Double, userMaxKm: Int): Double {
        val byMag = when {
            mag < 3.5 -> 0.0
            mag < 4.0 -> 60.0
            mag < 4.5 -> 120.0
            mag < 5.0 -> 200.0
            mag < 5.5 -> 300.0
            mag < 6.0 -> 450.0
            else -> 700.0
        }
        return minOf(byMag, userMaxKm.toDouble())
    }
}
